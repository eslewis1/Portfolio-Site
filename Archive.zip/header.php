<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE-edge">
    <meta name="viewport" content="width, initial-scale=1">
    <title> Erica Lewis</title>
    <link rel="stylesheet" type="text/css" href="stylesheet.css">
    <link href="https://fonts.googleapis.com/css?family=Raleway:100,300,400" rel="stylesheet">
</head>

<body>
    <header>
        <div id="innerWrapper">
                        <a id = "logo" href="index.php" style="text-decoration:none;">
                            <span style="color:#7E7F7F">ERICA</span>
                            <span style="color:#21A57F">LEWIS</span>
                        </a>
            <nav>
                        <p class="right"> <a href="#">RESUME</a></p>
                        <p class="right"> <a href="about.php">ABOUT</a></p>
                        <p class="right"> <a href="index.php">WORK</a></p>
            </nav>
        </div>
    </header>