<!DOCTYPE html>
<html>
    <?php include("header.php");?>

    <div>
        <p id="introT">I am a <span class="highlight">UX designer</span> and <span class="highlight">materials engineer</span> improving <br>the way that people interact with technology.

    </div>






    <div id="project-gallery">
        <div class="gallery-item" style="background-color:#ED4437"><img src="images/wt.png">
            <div class="gallery-item-overlay">
                <h1>Title of Product</h1>
                <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aliquam eget nisl pharetra, efficitur mi dictum, pulvinar elit. Nam venenatis a purus nec tempus. Vivamus ut mi quis eros laoreet tristique eget in orci. Aliquam mattis urna in felis volutpat, eu efficitur ligula consectetur. Donec at aliquet arcu. Nulla in elit tellus. </p>
                <!-- custom CSS button -->
                <div class="btn"><a>Read More</a></div>
            </div>
        </div>
        <div class="gallery-item" style="background-color: #58CCB6"> <img src="rock.png">
            <div class="gallery-item-overlay">
                <h1>Title of Product</h1>
                <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aliquam eget nisl pharetra, efficitur mi dictum, pulvinar elit. Nam venenatis a purus nec tempus. Vivamus ut mi quis eros laoreet tristique eget in orci. Aliquam mattis urna in felis volutpat, eu efficitur ligula consectetur. Donec at aliquet arcu. Nulla in elit tellus. </p>
                <!-- custom CSS button -->
                <div class="btn"><a>Read More</a></div>
            </div>
        </div>
        <div class="gallery-item" style="background-color:#213872"><img src="rock.png">
            <div class="gallery-item-overlay">
                <h1>Title of Product</h1>
                <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aliquam eget nisl pharetra, efficitur mi dictum, pulvinar elit. Nam venenatis a purus nec tempus. Vivamus ut mi quis eros laoreet tristique eget in orci. Aliquam mattis urna in felis volutpat, eu efficitur ligula consectetur. Donec at aliquet arcu. Nulla in elit tellus. </p>
                <!-- custom CSS button -->
                <div class="btn"><a>Read More</a></div>
            </div>
        </div>
        <div class="gallery-item" style="background-color: #efe1b5"><img src="rock.png">
            <div class="gallery-item-overlay">
                <h1>Title of Product</h1>
                <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aliquam eget nisl pharetra, efficitur mi dictum, pulvinar elit. Nam venenatis a purus nec tempus. Vivamus ut mi quis eros laoreet tristique eget in orci. Aliquam mattis urna in felis volutpat, eu efficitur ligula consectetur. Donec at aliquet arcu. Nulla in elit tellus. </p>
                <!-- custom CSS button -->
                <div class="btn"><a>Read More</a></div>
            </div>
        </div>

















<!--
    <div id="project-gallery">
        <div class="gallery-item" style="background-color:#ED4437"><img src="images/wt.png" style = "padding: 0em; max-width: 34em; max-height: 60em;">
            <div id="overlay"></div>
        </div>

        <div class="gallery-item" style="background-color: #58CCB6"><img src="images/iphone.png" style="height:20em;" ></div>
        <div class="gallery-item" style="background-color:#213872"><img src="images/robot.png"></div>
        <div class="gallery-item" style="background-color: #efe1b5"><img src="images/websitepage.png"></div>
    </div>

 -->

    <div id="bottom"></div>



</body>
</html>